package fnaf.aim.groupA.maps;

// Type of location
public enum LocationType {
    ROOM,
    HALLWAY,
    WINDOW
}


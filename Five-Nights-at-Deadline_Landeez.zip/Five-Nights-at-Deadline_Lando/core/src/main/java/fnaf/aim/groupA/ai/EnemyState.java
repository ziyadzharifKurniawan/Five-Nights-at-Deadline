package fnaf.aim.groupA.ai;

public enum EnemyState {
    ROAMING,
    AT_WINDOW,
    RETREATING,
    JUMPSCARE
}
